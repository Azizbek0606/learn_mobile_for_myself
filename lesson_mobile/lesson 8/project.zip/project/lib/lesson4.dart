import 'package:flutter/material.dart';

class lesson4 extends StatefulWidget {
  const lesson4({super.key});

  @override
  State<lesson4> createState() => _lesson4State();
}

class _lesson4State extends State<lesson4> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(icon: Icon(Icons.home) , label: "Home page"),
        BottomNavigationBarItem(icon: Icon(Icons.info) , label: "Info page"),
      ]),
    );
  }
}
