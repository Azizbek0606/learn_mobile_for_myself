package com.example.shopping

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
